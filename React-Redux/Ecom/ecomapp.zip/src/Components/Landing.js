export default function Landing() {
  return (
    <div>
      <h1>Welcome to Digi-Shop</h1>
    </div>
  );
}
